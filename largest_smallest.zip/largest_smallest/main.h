#include<stdio.h>
int array_elements(int* arr, int n);
int largest_smallest(int* arr, int n);
