#include"main.h"
int array_elements(int* arr, int n)
{
		printf("Enter array elements : ");
		for(int i = 0; i < n; i++)
		{
				scanf("%d", &arr[i]);
		}
}
