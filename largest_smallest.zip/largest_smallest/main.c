//WAP to find maximum and minimum element in an array 

#include"main.h"
int main()
{
		int n;
		printf("Enter size of an array : ");
		scanf("%d", &n);
		int arr[n];
		array_elements(arr, n);
		largest_smallest(arr,n);
		printf("largest element : %d\nsmallest element : %d\n",arr[n - 1],arr[0]);
		return 0;
}
