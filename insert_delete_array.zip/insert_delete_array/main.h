#include<stdio.h>
int delete_element(int* arr, int size);
int insert_element(int* arr, int size);
