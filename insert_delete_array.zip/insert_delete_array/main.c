//Program to delete/insert an from the array

#include"main.h"
int main()
{
		int size,option;
		printf("Enter array size : \n");
		scanf("%d", &size);
		int arr[size];
		printf("Enter array elements ; \n");
		for(int i = 0; i < size; i++)
		{
				scanf("%d", &arr[i]);
		}
		printf("Select option(1/2):\n1.Delete an element from the array \n2.Insert an element from the array \n");
		scanf("%d", &option);
		switch(option)
		{
				case 1 :
						delete_element(arr, size);
						break;
				case 2:
						insert_element(arr, size);
						break;
				default :
						printf("No action\n");
						break;
		}
}
