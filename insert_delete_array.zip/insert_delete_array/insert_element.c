#include"main.h"
int insert_element(int* arr, int size)
{
		int flag = 0,loc,x;
		printf("Enter the location to insert an element : \n");
		scanf("%d", &loc);
		if(loc >= size + 1)
		{
				flag = 1;
				printf("Error : Insertion is not possible\n");
		}
		else
		{
				printf("Enter an element to insert : ");
			    scanf("%d", &x);
			    size++;
				for(int i = size-1; i >= loc; i--)
				{
						arr[i] = arr[i - 1];
				}
				arr[loc - 1] = x;
		}
		if(flag != 1)
		{
				printf("The resultant array is : \n");
				for(int i = 0; i < size-1; i++)
				{
						printf("%d ", arr[i]);
				}
				printf("\n");
		}
}
