#include"main.h"
int delete_element(int* arr, int size)
{
		int flag = 0, loc;
		printf("Enter the location to delete an element from the array : \n");
		scanf("%d", &loc);
		if(loc >= size + 1)
		{
				flag = 1;
				printf("Error : Deletion is not possible\n");
		}
		else
		{
				for(int i = loc-1; i < size-1; i++)
				{
						arr[i] = arr[i+1];
				}
		}
		if(flag != 1)
		{
				printf("The resultant array is : \n");
				for(int i = 0; i < size-1; i++)
				{
						printf("%d ", arr[i]);
				}
				printf("\n");
		}
}
