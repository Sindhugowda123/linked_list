#include"main.h"
char string_concat(char* dest,char* src)
{
		int j = strlen(dest);
		for(int i = 0; src[i] != '\0'; i++)
		{
				dest[j] = src[i];
				j++;
		}
		dest[j] = '\0';
}
