//Program to concatenate two strings and find length of a new string.

#include"main.h"
int main()
{
		char src[20], dest[40];
		printf("Enter source string : ");
		scanf("%s", src);
		printf("Enter destination string : ");
		scanf("%s", dest);
		string_concat(dest,src);
		printf("Concatenated string is : %s\n", dest);
		int length = string_newlength(dest);
		printf("New string length is : %d\n", length);
}
