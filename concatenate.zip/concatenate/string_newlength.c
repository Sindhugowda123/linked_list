#include"main.h"
int string_newlength(char* dest)
{
		int length=0,i=0;
		while(dest[i] != '\0')
		{
				length++;
				i++;
		}
		return length;
}
