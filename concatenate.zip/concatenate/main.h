#include<stdio.h>
#include<string.h>
char string_concat(char* dest,char* src);
int string_newlength(char *dest);
