#include<stdio.h>
int string_length(char *str);
int string_palindrome(char* str, int count);

