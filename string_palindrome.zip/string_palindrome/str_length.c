#include"main.h"
int string_length(char *str)
{
		int count = 0,i = 0;
		while(str[i] != '\0')
		{
				count++;
				i++;
		}
		return count;
}


