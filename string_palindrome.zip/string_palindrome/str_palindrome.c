#include"main.h"
int string_palindrome(char* str, int count)
{
		int i, flag = 0;
		for(i = 0; i < count/2 ; i++)
		{
				if(str[i] == str[count - i - 1])
				{
						flag++;
				}
		}
		if(flag == i)
				return 1;
		else
				return 0;
}

