//Wap to check whether the given string is palindrome or not

#include"main.h"
int main()
{
		char str[20];
	    printf("Enter string : ");
		scanf("%s", str);
		int count = string_length(str);
		int flag = string_palindrome(str, count);
		if(flag == 1)
		printf("String is palindrome\n");
		else
		printf("String is not a palindrome\n");
}
