#include<stdio.h>
int copy_array(int *arr1, int* arr2, int size);
int print_array(int* arr2, int size);
