#include"main.h"
int print_array(int *arr2, int size)
{
	    printf("Elements copied to arr2[%d] from arr1[] are : ", size);
		for(int i = 0; i < size; i++)
		{
				printf("%d ", arr2[i]);
		}
printf("\n");
}
