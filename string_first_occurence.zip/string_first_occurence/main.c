//WAP to find the first occurence of a word in a given string.

#include"main.h"
int main()                                       
{
  char str[100];
  printf("Enter a string containing more than one word : ");
  scanf("%[^\n]%*c", str);
  char str1[20];
  printf("Enter a word to search for : ");
  scanf("%[^\n]%*c", str1);
  printf("%s\n", str_occurence(str, str1));
}
