#include<stdio.h>
#include<stdio_ext.h>
char* str_occurence(char* str, char* str1);
int string_compare(char* str, char* str1);
