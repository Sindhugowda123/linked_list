#include"main.h"

int string_compare(char* str, char* str1)
{
		while(*str && *str1)
		{
				if(*str != *str1)
				{
					return 0;
				}
				str++;
				str1++;
		}
		return (*str1 == '\0');
}
