#include"main.h"
char* str_occurence(char* str, char* str1)                
{
		while(*str != '\0')
		{
				if((*str == *str1) && string_compare(str,str1))
						{
								return str;
						}
				str++;
		}
		return NULL;
}

