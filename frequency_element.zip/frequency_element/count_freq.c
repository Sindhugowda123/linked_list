#include"main.h"

int flag = -1;
int count;


void count_freq(int *arr, int *freq, int size)
{
	for(int i=0;i<size;i++)
	{
		count = 1;
		for(int j=i+1;j<size;j++)
		{
			if(arr[i] == arr[j])
			{
				count++;
				freq[j] = flag;
			}
		}
		if(freq[i] != flag)
		{
			freq[i] = count;
		}
	}
}
