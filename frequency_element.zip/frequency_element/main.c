//WAP to count frequency of each element in an array.

#include"main.h"

int main()
{
	int size;
	printf("Enter array size: ");
	scanf("%d", &size);
	int arr[size];
	int freq[size];
	scan_array(arr, size);
    count_freq(arr,freq,size);
	print_freq(arr, freq, size);
}
