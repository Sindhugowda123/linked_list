#include<stdio.h>

void scan_array(int *arr, int size);
void count_freq(int *arr, int *freq, int size);
void print_freq(int *arr, int *freq, int size);

extern int flag;
extern int count;

